<?php

namespace plugins\goo1\scoringdance;

class core {
	
  public static function init() {
	  
    do_action("goo1_scoringdance_loaded");
  }


}